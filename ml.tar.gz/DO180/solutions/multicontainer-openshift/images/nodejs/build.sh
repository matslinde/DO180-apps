#!/bin/sh

sudo podman build -t do180/nodejs .
