#!/bin/bash

node app.js

