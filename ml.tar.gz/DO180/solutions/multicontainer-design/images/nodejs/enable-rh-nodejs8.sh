#!/bin/bash
source /opt/rh/rh-nodejs8/enable
export X_SCLS="`scl enable rh-nodejs8 'echo $X_SCLS'`"
