<?php
print "Hello, World! php version is " . PHP_VERSION . "\n";
?>
