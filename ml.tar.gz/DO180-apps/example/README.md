This file is used to test the Git repo setup on the infrastructure machine.
